//Import Require Modules
const express = require('express')
const mongoose=require('mongoose')
const userRouter=require('./routers/user')
const productRouter=require('./routers/product')
const keys=require('../config/keys')
const passport=require('passport')
const GoogleStrategy=require('passport-google-oauth2').Strategy
const cookieSession=require('cookie-session')
const fs=require('fs')
require('./passport/passport')

// CODE BEGINS HERE

const app=express()  //Create Instance of Express

app.use(cookieSession({
    maxAge:24*60*60*1000,   //Age of cookie
    keys:["thisiscookie-poc"]   //Cookie key
}))

app.use(passport.initialize())   //Intialize the authentication module
app.use(passport.session())     //Manage the session using cookie


//Connect With Database on Localhost
mongoose.connect(process.env.MONGODB_URL,{
    useNewUrlParser: true,       //Avoid deprecating Warning
    useCreateIndex: true,
    useFindAndModify:false,
    useUnifiedTopology: true,
})

app.use(express.json()) //Middleware to recognize JSON object of req
app.use(userRouter)     //Use userRouter
app.use(productRouter)  //Use productRouter

// google strategy intialize from here
app.get('/auth/google',passport.authenticate('google', { scope: 
    [ 'profile','email'] }
));

app.get('/auth/google/callback',passport.authenticate('google'),(req,res)=>{
  res.redirect('/api/user/loginUser')
})

const PORT=process.env.PORT    //Set Port Number
app.listen(PORT, () => {
    console.log('Server is up on port '+PORT)
})