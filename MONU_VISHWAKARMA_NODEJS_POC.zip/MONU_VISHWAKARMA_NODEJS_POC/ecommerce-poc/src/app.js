const express=require('express')
const userRouter=require('./routers/user')
const productRouter=require('./routers/product')
const mongoose=require('mongoose')

//Connect With Database on Localhost
mongoose.connect(process.env.MONGODB_URL,{
    useNewUrlParser: true,       //Avoid deprecating Warning
    useCreateIndex: true,
    useFindAndModify:false,
    useUnifiedTopology: true,
})

const app=express()

app.use(express.json())
app.use(userRouter)
app.use(productRouter)

module.exports=app
