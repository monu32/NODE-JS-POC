//Import require modules
const User=require('../models/user')
const Product=require('../models/product')
const sharp=require('sharp')
const fs=require('fs')
const auth=require('../middleware/auth')
const jwt=require('jsonwebtoken')


//Login user
exports.loginUser=(req,res)=>{
    res.send("Login succssfully...Use postman for rest of the endpoints")
}

// Create new user
exports.createUser=async (req,res)=>{
    try
    {
     const user=new User(req.body)
     await user.save()
     res.send(user)
    }
    catch(error)
     {
         res.status(500).send(error)
     }
}

//Get profile of user
exports.getUser=async (req,res)=>{
    res.status(200).send(req.user)
}

//Update user
exports.updateUser=async (req,res)=>{
    const updates=Object.keys(req.body)
    const allow=['userName','email','mobile',"address.houseNo","address.street",
    "address.landmark","address.city","address.state","orders.productId","orders.orderDate"
    ,"orders.quantity","orders.status"]
    const isvalidation=updates.every(update=>allow.includes(update))

   if(!isvalidation)
     return res.status(400).send("Invalid updates")
    try
    {
       const googleId=fs.readFileSync("LOGIN_ID.txt", "utf8")
       const user=await User.findOneAndUpdate({googleId},req.body,{new:true,runValidators:true})
       if(!user)
        return res.status(404).send()      
       await user.save()
       res.send(user)
    }
    catch(error)
     {
        res.status(500).send(error)
     }
}    

//Get all available products
exports.getAllProducts=async(req,res)=>
{
    try
    {
      const product=await Product.find({})
      res.status(200).send(product)
    }
    catch(error)
    {
      res.status(500).send()
    }  
}


// Update orders list (purchase new product)
exports.updateOrdersList=async (req,res)=>{
    try
    {   
     const googleId=fs.readFileSync("LOGIN_ID.txt", "utf8")
     if(!req.params.productId || !req.params.quantity)
      return res.status(400).send("Product not found")
     const product=await Product.findById(req.params.productId)
     if(!product)
      return res.status(404).send("Product not found")
    
     if(product.InStock==false || !product.quantity)
      return res.status(200).send("Product is not available")     
     const user=await User.findOne({googleId})
     if(!user)
      return res.status(404).send()
    
     product.quantity=product.quantity-req.params.quantity  
     if(product.quantity<0)
      product.quantity=0
      
     req.body.quantity=req.params.quantity
     req.body.productId=req.params.productId
     user.orders.push(req.body)
     await user.save() 
     await product.save() 
     res.status(200).send(user) 
    }
    catch(error)
    {
     res.status(500).send(error)    
    }
}

//Get all orders from list
exports.getAllOrders=async (req,res)=>{
    try
    {
     const googleId=fs.readFileSync("LOGIN_ID.txt", "utf8")
     const product=await User.find({googleId},{userName:true,orders:true})
     if(!product)
      return res.status(404).send()
     res.status(200).send(product)
    }
    catch(error)
     {
         res.status(500).send(error)
     }
}

//Delete user
exports.deleteUser=async (req,res)=>{
    try
    {
     const googleId=fs.readFileSync("LOGIN_ID.txt", "utf8") 
     fs.writeFileSync("LOGIN_ID.txt","")
     const user=await User.findOneAndDelete({googleId})
     if(!user)
      return res.status(404).send()
     fs.writeFileSync("LOGIN_ID.txt","") 
     req.logout()
     res.status(200).send(user)
    }
    catch(error)
    {
     res.status(500).send(error)         
    }
}

//Add picture
exports.addUserImage=async(req,res)=>{
    try
    {
     const googleId=fs.readFileSync("LOGIN_ID.txt", "utf8")     
     const buffer=await sharp(req.file.buffer).resize({width:250,height:250}).png().toBuffer()
     const user=await User.findOne({googleId})
     if(!user)
      return res.status(404).send()
     user.image=buffer
     await user.save()
     res.status(200).send("Image uploaded successfully")
    }
    catch(error)
     {
         res.status(500).send(error)
     }
}

//Get user image
exports.getUserImage=async(req,res)=>{
    try
    {
     const googleId=fs.readFileSync("LOGIN_ID.txt", "utf8")
     const user=await User.findOne({googleId})
     if(!user || !user.image)
        return res.status(404).send("Either User or image is missing")
     res.set('Content-type','image/png') 
     res.send(user.image)
    }
    catch(error)
    {
     res.status(500).send(error)
    }
}

//Delete user image
exports.deleteUserImage=async(req,res)=>{
    try
    {
     req.logout()
     const googleId=fs.readFileSync("LOGIN_ID.txt", "utf8")
     const user=await User.findOne({googleId})
     if(!user)
      return res.status(404).send()
     user.image=undefined
     await user.save()
     res.status(200).send("Deleted sucessfully")
    }
    catch(error)
     {
       res.status(500).send(error)
     }
}

// Logout user
exports.logoutUser=async (req,res)=>{
    try
    { 
       const googleId=fs.readFileSync("LOGIN_ID.txt") 
       const user=await User.findOne({googleId})
       if(!user)
        return res.status(404).send()
       user.token=""
       fs.writeFileSync("LOGIN_ID.txt","")
       await user.save()
       req.logout()     
       res.send('LOGOUT SUCCESSFULLY')    
    }
    catch(error)
    {
       res.status(500).send(error)
    }
}
