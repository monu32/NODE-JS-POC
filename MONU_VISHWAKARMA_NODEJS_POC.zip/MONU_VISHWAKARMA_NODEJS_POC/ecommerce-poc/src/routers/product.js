// import Require Modules
const express=require('express')
const router=new express.Router()
const productController=require('../controllers/product')
const multer=require('multer')

//get all products
router.get('/api/product/getProducts',productController.getProducts)

//get single product by id
router.get('/api/product/getProduct/:id',productController.getProduct)

// Enter new product in database
router.post('/api/product/newProduct',productController.newProduct) 

// update product by id
router.patch('/api/product/updateProduct/:id',productController.updateProduct) 

// delete product by id
router.delete('/api/product/deleteProduct/:id',productController.deleteProduct) 

//Create an instance on multer to upload image
const upload=multer({
    limits:{
        fileSize:1000000
    },
    fileFilter(req,file,cb){
        if(!file.originalname.match(/\.(jpg|jpeg|png)/))
         return cb(new Error("Please upload either jpg,jpeg or png"))
        cb(undefined,true)
    }
})

//Add image of prodcut
router.post('/api/product/addProductImage/:id',upload.single('imageKey'),productController.addProductImage,    
(error,req,res,next)=>res.status(400).send({error:error.message}))

//Get image of user
router.get('/api/product/getProductImage/:id',productController.getProductImage)

//Delete user image
router.delete('/api/product/deleteProductImage/:id',productController.deleteProductImage)

module.exports=router
