//Import modules
const request = require('supertest')
const app = require('../src/app')
const jwt=require('jsonwebtoken')
const mongoose=require('mongoose')
const User=require('../src/models/user')

//Create instance of product
const user={
    _id:new mongoose.Types.ObjectId(),
    name: 'david beckham',
    email: 'david7@example.com',
    googleId:"1",
    token: jwt.sign({_id:"1"}, process.env.JWT_SECRET)
}

//Test cases begins here
test('Should signup a new user', async () => {
    await User.deleteMany()
    await request(app).post('/api/user/createUser').send({
        _id:user._id,
        userName:user.name,
        googleId:user.googleId,
        email:user.email,
        token: user.token
    }).expect(200)
})

test('Should get profile of user', async () => {
    await request(app)
        .get('/api/user/getUser/')
        .set('Authorization',`Bearer ${user.token}`)
        .send()
        .expect(200)
})

test('Should not get profile for user', async () => {
    await request(app)
        .get('/api/user/getUser/')
        .send()
        .expect(401)
})

test('Should get all orders', async () => {
    await request(app)
        .get('/api/user/getAllOrders')
        .set('Authorization',`Bearer ${user.token}`)
        .send()
        .expect(200)
})

test('Should not get all orders', async () => {
    await request(app)
        .get('/api/user/getAllOrders')
        .send()
        .expect(401)
})

test('Should get image of user', async () => {
    await request(app)
        .get('/api/user/getUserImage')
        .set('Authorization',`Bearer ${user.token}`)
        .send()
        .expect(404)
})

test('Should not get image of user', async () => {
    await request(app)
        .get('/api/user/getUserImage')
        .send()
        .expect(401)
})

