//Import require modules
const Product=require('../models/product')
const sharp=require('sharp')

// get all products
exports.getProducts=async (req,res)=>{
  try
  {
    const product=await Product.find({})
    res.status(200).send(product)
  }
  catch(error)
  {
    res.status(500).send()
  }
}

//get product by id
exports.getProduct=async (req,res)=>{
  try
  {
    const product=await Product.findById(req.params.id)
    if(!product)
      res.status(404).send()
    res.status(200).send(product)
  }
  catch(error)
   {
     res.status(500).send()
   }
}

// Enter new product in database
exports.newProduct=async (req,res)=>{
  try
  {
    const product=new Product(req.body)    
    await product.save()
    res.status(201).send(product)
  }
  catch(error)
   {
     res.status(500).send(error)
   }
}

//update product 
exports.updateProduct=async (req,res)=>{
  try
  {
    const product=await Product.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true})
    if(!product)
     res.status(404).send()
    res.status(200).send(product)
  }
  catch(error)
   {
     res.status(500).send(error)
   }
}

// Delete product from databse
exports.deleteProduct=async (req,res)=>{
  try
  {
    const product=await Product.findByIdAndDelete(req.params.id)
    if(!product)
     res.status(404).send()
    res.status(200).send(product)
  }
  catch(error)
  {
    res.status(500).send()
  }
}

//Add picture for product
exports.addProductImage=async(req,res)=>{
  try
  {
   const buffer=await sharp(req.file.buffer).resize({width:250,height:250}).png().toBuffer()
   const product=await Product.findById(req.params.id)
   if(!product)
    return res.status(404).send()
   product.image=buffer
   await product.save()
   res.status(200).send(product)
  }
  catch(error)
   {
       res.status(500).send(error)
   }
}

//Get product image
exports.getProductImage=async(req,res)=>{
  try
  {
   const product=await Product.findById(req.params.id)
   if(!product || !product.image)
      return res.status(404).send("Either User or image is missing")
   res.set('Content-type','image/png') 
   res.send(product.image)
  }
  catch(error)
  {
   res.status(500).send(error)
  }
}

//Delete product image
exports.deleteProductImage=async(req,res)=>{
  try
  {
   const product=await Product.findById(req.params.id)
   if(!product)
    return res.status(404).send()
    product.image=undefined
   await product.save()
   res.status(200).send()
  }
  catch(error)
   {
     res.status(500).send(error)
   }
}
