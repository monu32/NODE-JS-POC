module.exports={
    googleClientId:"1010085093854-ugakbbtmtjiiarme7fanmf3j2d1fi99e.apps.googleusercontent.com",
    googleClientSecret:"inhQuVwrxTJWlEp422joquFr",
    keys:"thisiscookie-key"
}