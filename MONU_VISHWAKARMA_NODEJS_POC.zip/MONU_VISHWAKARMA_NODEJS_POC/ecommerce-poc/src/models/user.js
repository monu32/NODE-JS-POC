//Import Require Modules
const mongoose = require('mongoose')
const validator = require('validator')
const jwt=require('jsonwebtoken')

//Create Schema of User
const userSchema=new mongoose.Schema({
    userName: 
    {
        type:String,
        required:true,
        trim:true
    },
    googleId:
    {
        type:String,
        required:true
    },
    mobile:
    {
        type:Number,
        validate(value) 
        {
            if((value.length===10)===true)
                throw new Error('Mobile number is INVALID')
        }
    },
    email:
    {
        type:String,
        unique:true,
        required:true,
        validate(value)
        {
            if(!validator.isEmail(value))
              throw new Error("Email is INVALID")
        }
    },
    password:
    {
        type:String,
        validate(value)
        {
            if(value.length<8)
             throw new Error("Password is INVALID")
        }
    },
    address:
    {
     houseNo:
      {
          type:Number,
          validate(value)
          {
              if(value<0)
                throw new Error("House Number INVALID")
          }
      },
      street:
      {
          type:String,
          trim:true
      },
      landmark:
      {
          type:String,
          trim:true
      },
      city:
      {
          type:String,
          trim:true
      },
      state:
      {
          type:String,
          trim:true
      }
    }, 
    orders:
    [{
        orderDate:
        {
            type:Date,
            required:true
        },
        productId:
        {
            type:String,
            required:true
        },
        quantity:
        {
            type:Number,
            required:true,
            validate(value)
             {
                 if(value<0)
                  throw new Error("Quantity is INVALID")
             }
        },
        status:
        {
            type:String,
            required:true,
            lowercase:true,
            enum:["dispatched","shipped","received"]
        }
    }],
    token:{
        type:String,
    },
    image:{
        type:Buffer
    }
},{timestamps:true})

//Genereate authentication token
userSchema.methods.generateAuthToken=async function()
{
    const user=this
    const token=jwt.sign({_id:user.googleId.toString()},process.env.JWT_SECRET)
    user.token=token
    await user.save()
    return token
}

const User = mongoose.model('User',userSchema)
module.exports = User
